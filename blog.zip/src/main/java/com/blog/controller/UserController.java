package com.blog.controller;
import com.blog.common.JwtUtil;
import com.blog.common.Result;
import com.blog.entity.User;
import com.blog.service.UserService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/user")
public class UserController {
    @Resource
    private UserService userService;
    @Resource
    private JwtUtil jwtUtil;

    @PostMapping("/login")
    public Result<Map<String,Object>> login(@RequestBody User user) {
        User loginUser = userService.login(user.getUsername(), user.getPassword());
        if (loginUser == null) {
            return Result.fail("账号密码错误");
        }
        String token = jwtUtil.generateToken(loginUser.getId());
        Map<String,Object> map = new HashMap<>();
        map.put("user",loginUser);
        map.put("token",token);
        return Result.success(map);
    }
}