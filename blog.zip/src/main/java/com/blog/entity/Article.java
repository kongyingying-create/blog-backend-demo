package com.blog.entity;
import lombok.Data;
import com.baomidou.mybatisplus.annotation.TableName; // 导入注解

@Data
@TableName("t_article") // 对应数据库里的表名
public class Article {
    private Integer id;
    private String title;
    private String content;
    private Integer userId;
    private java.time.LocalDateTime createTime;
    private Integer viewCount;
}