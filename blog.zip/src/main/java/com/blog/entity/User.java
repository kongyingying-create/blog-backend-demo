package com.blog.entity;
import lombok.Data;
import com.baomidou.mybatisplus.annotation.TableName; // 导入注解

@Data
@TableName("t_user") // 对应数据库里的表名
public class User {
    private Integer id;
    private String username;
    private String password;
    private String nickname;
}