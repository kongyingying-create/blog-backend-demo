package com.blog.service;
import com.baomidou.mybatisplus.extension.service.IService;
import com.blog.entity.Article;
import java.util.List;
public interface ArticleService extends IService<Article> {
    List<Article> getHotArticle();
}